//On load a 2d canvas will be constructed with the dementions below
window.addEventListener("load", () => {
    var canvas = document.querySelector("#canvas");
    var ctx = canvas.getContext('2d');
	canvas.width = 700;
	canvas.height = 700;
			
	let painting = false;
	var tooltype = 'brush';
	function startPosition(e) { //function for starting new paint line
		painting = true;
		draw(e);
	}
	function finishedPosition() { //function for ending new paint line
		painting = false;
		ctx.beginPath()
	}
	function draw(e) { //function for actually drawing with the traits of the brush
		if (!painting) return;
		ctx.lineWidth = document.querySelector('#brushSize.value');
		ctx.lineCap = "round";
		ctx.lineTo(e.offsetX, e.offsetY); //had to use offset instead of client
		ctx.stroke();
		ctx.beginPath();
	    if(tooltype=='brush') { //loop to determine if canvas will be brushed or erased
            ctx.globalCompositeOperation = 'source-over';
            ctx.strokeStyle = `rgb(${red.value}, ${green.value}, ${blue.value})`;
        } else {
            ctx.globalCompositeOperation = 'destination-out'; //made the brush the color of the background
        }
		ctx.moveTo(e.offsetX, e.offsetY);
	}

	//Use draw|erase
	use_tool = function(tool) {
		tooltype = tool; //update
	}
	//EventListeners
	canvas.addEventListener("mousedown", startPosition); //runs startPosition function when mouse is clicked
	canvas.addEventListener("mouseup", finishedPosition); // runs finishedPosition function when mouse button is released
	canvas.addEventListener("mousemove", draw); //runs draw function while the mouse button held down
	
	//Begin brush size change with slider change
	var slide = document.getElementById('brushSize'),
		sliderDiv = document.getElementById("sliderAmount");

	slide.onchange = function() {
		ctx.lineWidth = this.value;
	}
	//End brush size change 
	
	/* function for the mouse x,y positioning from https://www.html5canvastutorials.com/advanced/html5-canvas-mouse-coordinates/ */

      function getMousePos(canvas, evt) {
        var rect = canvas.getBoundingClientRect();
        return {
          x: evt.clientX - rect.left,
          y: evt.clientY - rect.top
        };
      }

      canvas.addEventListener('mousemove', function(evt) {
        var mousePos = getMousePos(canvas, evt);
        position.textContent = mousePos.x + ',' + mousePos.y;
      }, false);	
	//End x,y positioning function

	//Begin button functions
	var brushButton = document.getElementById('brush').addEventListener('click', function() {		
		canvas.style.cursor = ('url(cursors/paintbrush.cur), default'),/* grabbed from http://www.rw-designer.com/cursor-library */
		ctx.strokeStyle = `rgb(${red.value}, ${green.value}, ${blue.value})`;
	});
	
	var eraserButton = document.getElementById('eraser').addEventListener('click', function() {
		canvas.style.cursor = ('url(cursors/eraser.cur), default'),/* grabbed from http://www.rw-designer.com/cursor-library */
		ctx.strokeStyle = 'white';
	});

	const saveButton = document.getElementById('save');
	
	// bind event handler to clear button
	const clearButton = document.getElementById('clear').addEventListener('click', function() {
		ctx.clearRect(0, 0, canvas.width, canvas.height);
	}, false);
	saveButton.addEventListener('click', () => onSave());
	
	function onSave() {
    var img = canvas.toDataURL("image/png");
    document.write('<img src="' + img + '"/>');
}
	//End button functions

/* Below loads script for modified rbg sliders - https://www.cssscript.com/demo/rgb-color-picker-slider/ */
	
	// moduled querySelector
	function qs(selectEl){
		return document.querySelector(selectEl);
	}

	// select RGB inputs
	let red = qs('#red'), 
	green = qs('#green'), 
	blue = qs('#blue'); 

	// selet num inputs
	let redNumVal = qs('#redNum'), 
	greenNumVal = qs('#greenNum'), 
	blueNumVal = qs('#blueNum');

	// select Color Display
	let colorDisplay = qs('#color-display');

	// select labels
	let redLbl = qs('label[for=red]'), 
	greenLbl = qs('label[for=green]'), 
	blueLbl = qs('label[for=blue]');

	// init display Colors
	displayColors();
	// init Color Vals
	colorNumbrVals();
	// init ColorSliderVals
	initSliderColors();
	// init Change Range Val
	changeRangeNumVal();
	// init Colors controls
	colorSliders();

	// display colors
	function displayColors(){
		colorDisplay.style.backgroundColor = `rgb(${red.value}, ${green.value}, ${blue.value})`;    
	}

	// initial color val when DOM is loaded 
	function colorNumbrVals(){
		redNumVal.value = red.value;
		greenNumVal.value = green.value;
		blueNumVal.value = blue.value;
	}

	// initial colors when DOM is loaded
	function initSliderColors(){
		// label bg colors
		redLbl.style.background = `rgb(${red.value},0,0)`;
		greenLbl.style.background = `rgb(0,${green.value},0)`;
		blueLbl.style.background = `rgb(0,0,${blue.value})`;

		// slider bg colors
		sliderFill(red);
		sliderFill(green);
		sliderFill(blue);
	}

	// Slider Fill offset
	function sliderFill(clr){
		let val = (clr.value - clr.min) / (clr.max - clr.min);
		let percent = val * 100;

		// clr input
		if(clr === red){
			clr.style.background = `linear-gradient(to right, rgb(${clr.value},0,0) ${percent}%, #cccccc 0%)`;    
		} else if (clr === green) {
			clr.style.background = `linear-gradient(to right, rgb(0,${clr.value},0) ${percent}%, #cccccc 0%)`;    
		} else if (clr === blue) {
			clr.style.background = `linear-gradient(to right, rgb(0,0,${clr.value}) ${percent}%, #cccccc 0%)`;    
		}
	}

	// change range values by number input
	function changeRangeNumVal(){

		// Validate number range
		redNumVal.addEventListener('change', ()=>{
			// make sure numbers are entered between 0 to 255
			if(redNumVal.value > 255){
				alert('cannot enter numbers greater than 255');
				redNumVal.value = red.value;
			} else if(redNumVal.value < 0) {
				alert('cannot enter numbers less than 0');  
				redNumVal.value = red.value;            
			} else if (redNumVal.value == '') {
				alert('cannot leave field empty');
				redNumVal.value = red.value;
				initSliderColors();
				displayColors();
			} else {
				red.value = redNumVal.value;
				initSliderColors();
				displayColors();
			}
		});

		// Validate number range
		greenNumVal.addEventListener('change', ()=>{
			// make sure numbers are entered between 0 to 255
			if(greenNumVal.value > 255){
				alert('cannot enter numbers greater than 255');
				greenNumVal.value = green.value;
			} else if(greenNumVal.value < 0) {
				alert('cannot enter numbers less than 0');  
				greenNumVal.value = green.value;            
			} else if(greenNumVal.value == '') {
				alert('cannot leave field empty');
				greenNumVal.value = green.value;
				initSliderColors();
				displayColors();
			} else {
				green.value = greenNumVal.value;            
				initSliderColors();
				displayColors();
			}
		});

		// Validate number range
		blueNumVal.addEventListener('change', ()=>{
			// make sure numbers are entered between 0 to 255
			if (blueNumVal.value > 255) {
				alert('cannot enter numbers greater than 255');
				blueNumVal.value = blue.value;
			} else if (blueNumVal.value < 0) {
				alert('cannot enter numbers less than 0');
				blueNumVal.value = blue.value;
			} else if(blueNumVal.value == '') {
				alert('cannot leave field empty');
				blueNumVal.value = blue.value;
				initSliderColors();
				displayColors();
			} else {
				blue.value = blueNumVal.value;            
				initSliderColors();
				displayColors();
			}
		});
	}

	// Color Sliders controls
	function colorSliders(){
		red.addEventListener('input', () => {
			displayColors();
			initSliderColors();
			changeRangeNumVal();
			colorNumbrVals();
		});

		green.addEventListener('input', () => {
			displayColors();
			initSliderColors();
			changeRangeNumVal();
			colorNumbrVals();
		});

		blue.addEventListener('input', () => {
			displayColors();
			initSliderColors();
			changeRangeNumVal();
			colorNumbrVals();
		});
	}

});	
